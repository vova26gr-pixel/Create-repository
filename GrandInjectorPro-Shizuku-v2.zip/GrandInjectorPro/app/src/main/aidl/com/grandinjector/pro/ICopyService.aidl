package com.grandinjector.pro;
interface ICopyService {
    String copy(String source, String destination);
    String testPath(String path);
}
