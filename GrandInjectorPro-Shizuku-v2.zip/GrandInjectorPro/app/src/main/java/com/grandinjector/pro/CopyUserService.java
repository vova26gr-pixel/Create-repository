package com.grandinjector.pro;

import android.os.Parcel;
import java.io.*;

public class CopyUserService extends ICopyService.Stub {
    private static final String ALLOWED = "/sdcard/Android/data/";
    private static final String ALLOWED2 = "/storage/emulated/0/Android/data/";

    @Override public String testPath(String path) {
        try {
            if (!allowed(path)) return "Запрещённый путь";
            File dir = new File(path);
            if (!dir.exists() && !dir.mkdirs()) return "Не удалось создать каталог";
            File probe = new File(dir, ".grandinjector_probe");
            try (FileOutputStream out = new FileOutputStream(probe)) { out.write(1); }
            if (!probe.delete()) { /* harmless */ }
            return "OK";
        } catch (Throwable t) { return "Ошибка доступа: " + t.getMessage(); }
    }

    @Override public String copy(String source, String destination) {
        try {
            if (!allowed(destination)) return "Запрещённый путь";
            File src = new File(source);
            if (!src.isFile()) return "Исходный файл не найден";
            File dir = new File(destination);
            if (!dir.exists() && !dir.mkdirs()) return "Не удалось создать каталог назначения";
            File dst = new File(dir, src.getName());
            File tmp = new File(dir, ".grandinjector_" + src.getName() + ".tmp");
            try (InputStream in = new BufferedInputStream(new FileInputStream(src)); OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp, false))) {
                byte[] buf = new byte[1024 * 1024]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            }
            outSync(tmp);
            if (dst.exists() && !dst.delete()) return "Не удалось заменить старый файл";
            if (!tmp.renameTo(dst)) return "Не удалось переименовать временный файл";
            return "OK";
        } catch (Throwable t) { return "Ошибка копирования: " + t.getMessage(); }
    }

    private boolean allowed(String path) {
        if (path == null) return false;
        String p = new File(path).getAbsolutePath();
        return (p.startsWith(ALLOWED) || p.startsWith(ALLOWED2)) && !p.contains("../") && !p.contains("/../");
    }

    private void outSync(File f) { try (FileOutputStream ignored = new FileOutputStream(f, true)) { ignored.getFD().sync(); } catch (Exception ignored) {} }

    @Override public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws android.os.RemoteException {
        if (code == 16777114) { System.exit(0); return true; }
        return super.onTransact(code, data, reply, flags);
    }
}
