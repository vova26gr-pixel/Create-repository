package com.grandinjector.pro

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.os.IBinder
import android.widget.EditText
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }
    private val PICK_FILES = 9001
    private var pendingUris = emptyList<Uri>()
    private var copyService: ICopyService? = null
    private var serviceArgs: Shizuku.UserServiceArgs? = null
    private var serviceConnection: ServiceConnection? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 100) {
            val ok = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
            web.post { web.evaluateJavascript("nativePermissionResult(1,$ok,${js("Shizuku: " + if (ok) "разрешено" else "отказано")})", null) }
            if (ok) ensureCopyService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                web.evaluateJavascript("nativePermissionResult(1,${hasShizukuPermission()},'Shizuku')", null)
                web.evaluateJavascript("nativePermissionResult(3,${Settings.canDrawOverlays(this@MainActivity)},'Оверлей')", null)
            }
        }
        web.webChromeClient = object : WebChromeClient() {}
        web.setBackgroundColor(Color.rgb(6, 8, 12))
        web.addJavascriptInterface(NativeBridge(), "NativeBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        Shizuku.addRequestPermissionResultListener(permissionListener)
        if (hasShizukuPermission()) ensureCopyService()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        try { serviceArgs?.let { Shizuku.unbindUserService(it, serviceConnection, false) } } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }

    private fun hasShizukuPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Exception) { false }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            toast("Сначала запустите Shizuku и разрешите доступ этому приложению")
            return
        }
        if (hasShizukuPermission()) {
            web.evaluateJavascript("nativePermissionResult(1,true,'Shizuku разрешено')", null)
            ensureCopyService()
            return
        }
        try { Shizuku.requestPermission(100) } catch (e: Exception) { toast("Ошибка Shizuku: ${e.message}") }
    }

    private fun ensureCopyService(onReady: (() -> Unit)? = null) {
        if (copyService != null) { onReady?.invoke(); return }
        if (!hasShizukuPermission()) { onReady?.invoke(); return }
        val args = Shizuku.UserServiceArgs(ComponentName(this, CopyUserService::class.java))
            .daemon(false).version(2).tag("copy-service").processNameSuffix("copy")
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                copyService = ICopyService.Stub.asInterface(service)
                web.post { web.evaluateJavascript("nativePermissionResult(2,true,'Сервис Shizuku готов')", null) }
                onReady?.invoke()
            }
            override fun onServiceDisconnected(name: ComponentName?) { copyService = null }
        }
        serviceArgs = args
        serviceConnection = conn
        try { Shizuku.bindUserService(args, conn) }
        catch (e: Exception) { toast("Не удалось запустить Shizuku UserService: ${e.message}") }
    }

    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, PICK_FILES)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return
        val uris = buildList {
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) add(clip.getItemAt(i).uri) }
            data.data?.let { if (isEmpty()) add(it) }
        }
        if (uris.isEmpty()) return
        pendingUris = uris
        io.execute {
            uris.forEach { uri -> stageUri(uri) }
        }
    }

    private fun stageUri(uri: Uri) {
        try {
            val name = queryName(uri) ?: "file_${System.currentTimeMillis()}"
            val dir = File(externalCacheDir, "staging").apply { mkdirs() }
            val out = File(dir, safeName(name))
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Не удалось открыть файл" }
                out.outputStream().use { output -> input.copyTo(output) }
            }
            val token = out.absolutePath
            prefs.edit().putString("lastToken", token).putString("lastName", name).apply()
            val size = out.length()
            runOnUiThread { web.evaluateJavascript("addNativeFile(${js(token)},${js(name)},$size)", null) }
        } catch (e: Exception) { runOnUiThread { toast("Не удалось загрузить файл: ${e.message}") } }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").take(180)

    private fun configureTarget() {
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(prefs.getString("target", "/sdcard/Android/data/com.grand.launcher/files"))
            setSelection(text.length)
            hint = "/sdcard/Android/data/com.grand.launcher/files"
        }
        AlertDialog.Builder(this).setTitle("Папка Grand Mobile").setMessage("Укажи папку назначения. Разрешены только каталоги внутри /sdcard/Android/data.")
            .setView(input).setNegativeButton("Отмена", null).setPositiveButton("Проверить") { _, _ ->
                val path = input.text.toString().trim().removeSuffix("/")
                if (!path.startsWith("/sdcard/Android/data/") && !path.startsWith("/storage/emulated/0/Android/data/")) {
                    toast("Для безопасности путь должен быть внутри Android/data")
                    return@setPositiveButton
                }
                prefs.edit().putString("target", path).apply()
                ensureCopyService {
                    io.execute {
                        val result = try { copyService?.testPath(path) ?: "Сервис Shizuku не готов" } catch (e: Exception) { "Ошибка: ${e.message}" }
                        runOnUiThread { web.evaluateJavascript("nativePermissionResult(2,${result == "OK"},${js(result)})", null) }
                    }
                }
            }.show()
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            web.evaluateJavascript("nativePermissionResult(3,true,'Оверлей разрешён')", null)
            return
        }
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) { requestOverlay(); return }
        try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (e: Exception) { toast("Оверлей: ${e.message}") }
    }

    private fun stopOverlay() { stopService(Intent(this, OverlayService::class.java)) }

    private fun inject(token: String) {
        val target = prefs.getString("target", "/sdcard/Android/data/com.grand.launcher")!!
        ensureCopyService {
            io.execute {
                val result = try { copyService?.copy(token, target) ?: "Сервис Shizuku не готов" } catch (e: Exception) { "Ошибка: ${e.message}" }
                runOnUiThread { web.evaluateJavascript("nativeInjectionResult(${result == "OK"},${js(result)})", null) }
            }
        }
    }

    private fun js(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    inner class NativeBridge {
        @JavascriptInterface fun requestShizuku() = runOnUiThread { requestShizuku() }
        @JavascriptInterface fun configureTarget() = runOnUiThread { configureTarget() }
        @JavascriptInterface fun requestOverlay() = runOnUiThread { requestOverlay() }
        @JavascriptInterface fun startOverlay() = runOnUiThread { startOverlay() }
        @JavascriptInterface fun stopOverlay() = runOnUiThread { stopOverlay() }
        @JavascriptInterface fun pickFiles() = runOnUiThread { pickFiles() }
        @JavascriptInterface fun inject(token: String) = runOnUiThread { inject(token) }
    }
}
