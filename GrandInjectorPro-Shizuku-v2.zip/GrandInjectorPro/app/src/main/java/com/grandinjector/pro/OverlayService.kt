package com.grandinjector.pro

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.content.pm.ServiceInfo
import android.view.*
import android.widget.*
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private var menu: LinearLayout? = null
    private val io = Executors.newSingleThreadExecutor()
    private var copyService: ICopyService? = null
    private var args: Shizuku.UserServiceArgs? = null
    private var conn: ServiceConnection? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_manage).setContentTitle("GrandInjector Pro")
            .setContentText("Плавающее меню активно").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(77, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "⚡"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(6, 8, 12)); setPadding(16, 10, 16, 10)
            setOnClickListener { toggleMenu() }
        }
        val lp = WindowManager.LayoutParams(64, 64, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = 12; y = 420
        }
        wm.addView(bubble, lp)
        bubble.setOnTouchListener(DragTouch(wm, bubble, lp) { toggleMenu() })
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun toggleMenu() {
        menu?.let { wm.removeView(it); menu = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16); setBackgroundColor(Color.rgb(15, 21, 32)) }
        val title = TextView(this).apply { text = "OVERLAY ENGINE"; textSize = 13f; setTextColor(Color.CYAN); setPadding(0,0,0,10) }
        val insert = Button(this).apply { text = "ВСТАВИТЬ ПОСЛЕДНИЙ ФАЙЛ"; setOnClickListener { copyLast(); } }
        val open = Button(this).apply { text = "ОТКРЫТЬ GRANDINJECTOR"; setOnClickListener { startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } }
        val close = Button(this).apply { text = "ЗАКРЫТЬ МЕНЮ"; setOnClickListener { toggleMenu() } }
        box.addView(title); box.addView(insert); box.addView(open); box.addView(close)
        val p = WindowManager.LayoutParams(330, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 490 }
        menu = box; wm.addView(box, p)
    }

    private fun ensureService(onReady: () -> Unit) {
        if (copyService != null) { onReady(); return }
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Toast.makeText(this, "Shizuku не разрешён", Toast.LENGTH_LONG).show(); return }
        val a = Shizuku.UserServiceArgs(ComponentName(this, CopyUserService::class.java)).daemon(false).version(1).tag("copy-service").processNameSuffix("copy")
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) { copyService = ICopyService.Stub.asInterface(service); onReady() }
            override fun onServiceDisconnected(name: ComponentName?) { copyService = null }
        }
        args = a; conn = c
        Shizuku.bindUserService(a, c)
    }

    private fun copyLast() {
        val p = getSharedPreferences("config", MODE_PRIVATE)
        val source = p.getString("lastToken", null); val target = p.getString("target", "/sdcard/Android/data/com.grand.launcher")
        if (source == null) { Toast.makeText(this, "Сначала выберите файл в приложении", Toast.LENGTH_LONG).show(); return }
        ensureService {
            io.execute {
                val result = try { copyService?.copy(source, target!!) ?: "Сервис не готов" } catch (e: Exception) { "Ошибка: ${e.message}" }
                Handler(Looper.getMainLooper()).post { Toast.makeText(this, if (result == "OK") "Файл вставлен" else result, Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("overlay", "GrandInjector overlay", NotificationManager.IMPORTANCE_LOW)) }

    override fun onDestroy() {
        try { menu?.let { wm.removeView(it) }; wm.removeView(bubble) } catch (_: Exception) {}
        try { args?.let { Shizuku.unbindUserService(it, conn, false) } } catch (_: Exception) {}
        io.shutdownNow(); super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    private class DragTouch(private val wm: WindowManager, private val view: View, private val lp: WindowManager.LayoutParams, private val click: () -> Unit) : View.OnTouchListener {
        var downX=0f; var downY=0f; var startX=0; var startY=0; var moved=false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=lp.x; startY=lp.y; moved=false; return true }
                MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt(); if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>12) moved=true; lp.x=(startX-dx).coerceAtLeast(0); lp.y=(startY+dy).coerceAtLeast(0); wm.updateViewLayout(view,lp); return true }
                MotionEvent.ACTION_UP -> { if(!moved) click(); return true }
            }; return false
        }
    }
}
